. ./setenv.sh
ORDERER_GENERAL_GENESISPROFILE=SampleSingleMSPSolo orderer
