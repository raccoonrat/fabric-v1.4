export GOPATH=/home/wangyh/gopath
export GOROOT=/home/wangyh/go

export PATH=$GOPATH/bin:$GOROOT/bin:$GOPATH/src/github.com/hyperledger/fabric/.build/bin:$PATH
export FABRIC_CFG_PATH=$GOPATH/src/github.com/hyperledger/fabric/sampleconfig/
