. ./setenv.sh
CORE_LOGGING_LEVEL=DEBUG peer node start
